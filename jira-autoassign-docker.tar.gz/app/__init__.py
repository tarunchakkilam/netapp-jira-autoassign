"""
Jira Auto-Assignment Service
Automated ticket assignment based on developer skills and workload.
"""

__version__ = "1.0.0"
